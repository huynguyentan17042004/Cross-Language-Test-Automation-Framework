
#include "dragon.h"
#include <iostream>
using namespace std;

int main() {
    
     Configuration* d = new Configuration("sa_tc_02_config");
d->setNumSteps(100);
    return 0;
}
